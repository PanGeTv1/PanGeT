################################ Instructions for running this program ###############################
#
#1.	keep this program inside the any of the strain folders present inside the
#       Output_folder (Ex. NC_0003196) 
#
#2. 	use one number lesser file than number of genomes you want to compare
#   	(if you want to find genes conseved in 5 genomes, use =>conserved_in_4-genomes file
#   	similarly for 4 genomes, use => conserved_in_3-genomes  file
#   	similarly for 2 genomes,use  => conserved_in_1-genomes  file)

#3.     Replace with your genome names you want to compare.
#
#
#######################################################################################################



my $file = "conserved_in_5-genomes";    #if you want to compare 6 genomes use conserved_in_5-genomes file ( one number lesser file )
open(ip_hand,"$file");
my $f_line = <ip_hand>;
print "$f_line\n";
my @arry = qw(NC_002677 NC_008595 NC_008611 NC_010612 NC_018143 NC_021282);  #replace with your genome names you want to compare. 
my $number=$#arry+1;

my @spl = split('\s+',$f_line);
my @val;
my @cds;


for(my $i=0;$i<=$#spl;$i++)
{
my $count=0;
		foreach my $ele(@arry)
		{
		
		$spl[$i]=~s/\s+//g;
		$spl[$i]=~s/\n//g;
		$ele=~s/\s+//g;
		$ele=~s/\n//g;

			if($ele eq $spl[$i])
			{
			
			$count=1;
			}
		}
	if($count==1)
	{
	my $f=$i-1;
	push(@val,$f);
	push (@cds,$spl[$i]);
	}

}



while(<ip_hand>)
{

	
	my $c=0;
	my $count_line=0;
	my @line = split('\s+',$_);

	my @a=grep( { $_ > 0.4 } @line);

	
        my $c=$#a+1;
				if ($c==$number-1)
				{
					foreach $l(@val)
					{
						if($line[$l]>0.42)
						{
						$count_line++; 
						}
					}
				}
		if ($count_line==$number-1)
		{
		print "$_\n";
		}



}
